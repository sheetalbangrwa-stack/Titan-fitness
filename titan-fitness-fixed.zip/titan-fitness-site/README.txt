TITAN FITNESS — WEBSITE PACKAGE
================================

WHAT'S IN THIS FOLDER
----------------------
index.html   Page structure (loads config.js + script.js, no content lives here)
style.css    All styling
script.js    Renders the site from config.js, then handles nav/menu/slider/etc.
config.js    ALL editable content — name, colors, copy, prices, contact info, etc.
images/      All photos, organized by section (about, gallery, trainers)

This is a fully static site — plain HTML/CSS/JS, no build step, no server-side
code, no dependencies to install.

HOW TO DEPLOY
--------------
Any static hosting works. A few common options:

1. Netlify / Vercel (drag-and-drop)
   - Go to app.netlify.com/drop (or vercel.com/new)
   - Drag this whole folder in
   - Done — you get a live URL immediately, custom domain optional

2. GitHub Pages
   - Push this folder's contents to a GitHub repo
   - Repo Settings -> Pages -> deploy from the main branch
   - Site goes live at yourusername.github.io/reponame

3. Any traditional web host (cPanel, FTP, etc.)
   - Upload every file and the images/ folder as-is to your host's
     public_html (or www/) directory, keeping the folder structure intact
   - Point your domain at that hosting account

STILL TO FINISH BEFORE GOING LIVE
-----------------------------------
Open config.js and search for these — they're still placeholders:

  - contact.phoneDisplay / phoneHref   currently "+91 XXXXXXXXXX"
  - contact.whatsappNumber             currently empty (WhatsApp button
                                        stays hidden until you add a number)
  - contact.mapEmbedUrl                currently a placeholder string
                                        (get a real embed link from Google
                                        Maps: Share -> Embed a map)
  - social.instagram / facebook /
    twitter / youtube                  currently placeholder text
                                        (leave any one as "" to hide that
                                        icon entirely)

Everything else (name, tagline, colors, hero, about, services, membership
plans, trainers, gallery, testimonials) is already filled in with your
real content.

EDITING LATER
--------------
To change ANY content on the site, edit config.js only. Do not edit
index.html/style.css/script.js unless you're changing the underlying
design or layout — those files are shared logic, not content.
